(function attachFilters(global) {
  function normalizeText(value) {
    return String(value || "").trim().toLowerCase();
  }

  function hasValue(value) {
    return value !== undefined && value !== null && value !== "";
  }

  function isPositiveNumber(value) {
    return typeof value === "number" && Number.isFinite(value) && value > 0;
  }

  function decideProduct(product, config) {
    const reasons = [];
    const titleBrand = `${product.title || ""} ${product.brand || ""}`.toLowerCase();

    if (!hasValue(product.url)) reasons.push("missing_url");
    if (!hasValue(product.title)) reasons.push("missing_title");

    const minSales = Number(config.minSales || 0);
    if (minSales > 0 && isPositiveNumber(product.sales) && product.sales < minSales) {
      reasons.push(`sales<${minSales}`);
    }

    const maxListingDays = Number(config.maxListingDays || 0);
    if (maxListingDays > 0 && isPositiveNumber(product.listingDays) && product.listingDays > maxListingDays) {
      reasons.push(`listing_days>${maxListingDays}`);
    }

    const maxSellerCount = Number(config.maxSellerCount || 0);
    if (maxSellerCount > 0 && Number.isFinite(product.sellerCount) && product.sellerCount > maxSellerCount) {
      reasons.push(`seller_count>${maxSellerCount}`);
    }

    const minPrice = Number(config.minPrice || 0);
    const maxPrice = Number(config.maxPrice || 0);
    if (minPrice > 0 && (!isPositiveNumber(product.priceRub) || product.priceRub < minPrice)) {
      reasons.push(`price<${minPrice}`);
    }
    if (maxPrice > 0 && (!isPositiveNumber(product.priceRub) || product.priceRub > maxPrice)) {
      reasons.push(`price>${maxPrice}`);
    }

    if (config.requireWeight && !hasValidWeight(product)) {
      reasons.push("missing_weight");
    }

    if (config.requireVolume && !hasValidVolume(product)) {
      reasons.push("missing_volume");
    }

    for (const keyword of config.forbiddenKeywords || []) {
      const normalized = normalizeText(keyword);
      if (normalized && titleBrand.includes(normalized)) {
        reasons.push(`forbidden_keyword:${keyword}`);
      }
    }

    for (const brand of config.blockedBrands || []) {
      const normalized = normalizeText(brand);
      if (normalized && normalizeText(product.brand).includes(normalized)) {
        reasons.push(`blocked_brand:${brand}`);
      }
    }

    return { accepted: reasons.length === 0, reasons };
  }

  function hasValidVolume(product) {
    if (isPositiveNumber(product.lengthCm) && isPositiveNumber(product.widthCm) && isPositiveNumber(product.heightCm)) {
      return true;
    }
    if (
      isPositiveNumber(product.dimensionsCm?.length) &&
      isPositiveNumber(product.dimensionsCm?.width) &&
      isPositiveNumber(product.dimensionsCm?.height)
    ) {
      return true;
    }
    return isPositiveNumber(product.volumeCm3);
  }

  function hasValidWeight(product) {
    return isPositiveNumber(product.weightGrams) || isPositiveNumber(product.weightKg);
  }

  global.MiaoshouOzonFilters = { decideProduct };
})(globalThis);
