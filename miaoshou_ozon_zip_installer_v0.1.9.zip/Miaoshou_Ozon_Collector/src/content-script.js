(function contentScript() {
  if (globalThis.__miaoshouOzonCollectorLoaded) return;
  globalThis.__miaoshouOzonCollectorLoaded = true;

  const STATE_KEY = "__miaoshouOzonCollectorState";

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "MIAOSHOU_SCAN_PAGE") {
      const config = message.config || {};
      const products = scanPage(config);
      sendResponse({ ok: true, products });
      return true;
    }

    if (message?.type === "MIAOSHOU_NEXT_PAGE") {
      const clicked = clickNextPage();
      sendResponse({ ok: true, clicked });
      return true;
    }

    if (message?.type === "MIAOSHOU_SCROLL_PAGE") {
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
      sendResponse({ ok: true });
      return true;
    }
  });

  function scanPage(config) {
    const cards = findProductCards();
    const seen = new Set();
    const products = [];
    const structuredProducts = extractStructuredProducts();

    for (const card of cards) {
      const product = mergeProductData(extractProduct(card), structuredProducts);
      if (!product.url || seen.has(product.url)) continue;
      seen.add(product.url);
      const decision = globalThis.MiaoshouOzonFilters.decideProduct(product, config);
      products.push({ ...product, accepted: decision.accepted, reasons: decision.reasons });
    }

    for (const product of structuredProducts) {
      if (!product.url || seen.has(product.url)) continue;
      seen.add(product.url);
      const decision = globalThis.MiaoshouOzonFilters.decideProduct(product, config);
      products.push({ ...product, accepted: decision.accepted, reasons: decision.reasons });
    }

    window[STATE_KEY] = { lastScanAt: new Date().toISOString(), products };
    return products;
  }

  function findProductCards() {
    const anchors = [...document.querySelectorAll('a[href*="/product/"]')];
    const cards = [];
    const seen = new Set();

    for (const anchor of anchors) {
      const card = findCardContainer(anchor);
      if (!card || seen.has(card)) continue;
      const text = compactText(card.innerText);
      if (text.length < 12) continue;
      seen.add(card);
      cards.push(card);
    }

    return cards;
  }

  function findCardContainer(anchor) {
    let node = anchor;
    let best = anchor;
    for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
      const text = compactText(node.innerText);
      const productLinks = node.querySelectorAll?.('a[href*="/product/"]').length || 0;
      if (productLinks > 1) break;
      if (text.length > compactText(best.innerText).length) best = node;
      if (text.length > 80 && productLinks === 1) return node;
    }
    return best.closest?.('[data-widget], [data-index], article') || best;
  }

  function extractProduct(card) {
    const anchor = card.querySelector('a[href*="/product/"]');
    const url = normalizeOzonUrl(anchor?.href || "");
    const text = compactText(card.innerText);
    const title = extractTitle(card, anchor, text);
    const metrics = extractMetrics(text);

    return {
      url,
      ozonProductId: extractOzonProductId(url),
      title,
      brand: extractByLabels(text, ["品牌", "Бренд", "Brand"]),
      imageUrl: extractImageUrl(card),
      priceRub: metrics.priceRub,
      rating: metrics.rating,
      reviewCount: metrics.reviewCount,
      sales: metrics.sales,
      listingDays: metrics.listingDays,
      sellerCount: metrics.sellerCount,
      weightGrams: metrics.weightGrams,
      lengthCm: metrics.lengthCm,
      widthCm: metrics.widthCm,
      heightCm: metrics.heightCm,
      volumeCm3: metrics.volumeCm3,
      rawText: text.slice(0, 3000)
    };
  }

  function extractTitle(card, anchor, text) {
    const aria = anchor?.getAttribute("aria-label");
    if (aria && aria.length > 5) return aria.trim();

    const titleLike = card.querySelector('[title], h1, h2, h3');
    const title = titleLike?.getAttribute("title") || titleLike?.innerText;
    if (title && title.trim().length > 5) return compactText(title).slice(0, 200);

    return text.split(/\s{2,}|\n/).find((part) => part.length > 8)?.slice(0, 200) || "";
  }

  function extractMetrics(text) {
    return {
      sales: firstNumber(text, [
        /销量[:：]?\s*([0-9]+(?:[.,][0-9]+)?\s*[kк千万]?\+?)/i,
        /已售[:：]?\s*([0-9]+(?:[.,][0-9]+)?\s*[kк千万]?\+?)/i,
        /продаж[а-я\s:：]*([0-9]+(?:[.,][0-9]+)?\s*[kк千万]?\+?)/i,
        /sold[:：]?\s*([0-9]+(?:[.,][0-9]+)?\s*[kк千万]?\+?)/i
      ]),
      listingDays: firstNumber(text, [
        /上架(?:天数|时间)?[:：]?\s*([0-9]+(?:[.,][0-9]+)?)\s*天/i,
        /([0-9]+(?:[.,][0-9]+)?)\s*天前上架/i,
        /listing\s*days?[:：]?\s*([0-9]+(?:[.,][0-9]+)?)/i,
        /days\s*online[:：]?\s*([0-9]+(?:[.,][0-9]+)?)/i
      ]),
      sellerCount: firstNumber(text, [
        /跟卖数[:：]?\s*([0-9]+(?:[.,][0-9]+)?\+?)/i,
        /卖家数[:：]?\s*([0-9]+(?:[.,][0-9]+)?\+?)/i,
        /seller[s]?\s*count[:：]?\s*([0-9]+(?:[.,][0-9]+)?\+?)/i,
        /продавц[а-я\s:：]*([0-9]+(?:[.,][0-9]+)?\+?)/i
      ]),
      priceRub: extractPriceRub(text),
      rating: firstNumber(text, [
        /рейтинг[:：]?\s*([0-9]+(?:[.,][0-9]+)?)/i,
        /rating[:：]?\s*([0-9]+(?:[.,][0-9]+)?)/i,
        /评分[:：]?\s*([0-9]+(?:[.,][0-9]+)?)/i
      ]),
      reviewCount: firstNumber(text, [
        /([0-9]+(?:[.,][0-9]+)?\s*[kк千万]?)\s*(?:отзыв|reviews?|评价|评论)/i,
        /(?:отзывов|reviews?|评价|评论)[:：]?\s*([0-9]+(?:[.,][0-9]+)?\s*[kк千万]?)/i
      ]),
      weightGrams: extractWeightGrams(text),
      ...extractDimensions(text)
    };
  }

  function extractStructuredProducts() {
    const products = [];
    for (const node of document.querySelectorAll('script[type="application/ld+json"]')) {
      const json = parseJson(node.textContent);
      for (const item of flattenJsonLd(json)) {
        if (!isProductLike(item)) continue;
        const offer = Array.isArray(item.offers) ? item.offers[0] : item.offers || {};
        const aggregateRating = item.aggregateRating || {};
        const url = normalizeOzonUrl(item.url || offer.url || location.href);
        products.push({
          url,
          ozonProductId: extractOzonProductId(url),
          title: compactText(item.name || ""),
          brand: compactText(typeof item.brand === "string" ? item.brand : item.brand?.name || ""),
          imageUrl: normalizeImageUrl(Array.isArray(item.image) ? item.image[0] : item.image),
          priceRub: parseMoney(offer.price || item.price),
          rating: parseMetricNumber(aggregateRating.ratingValue),
          reviewCount: parseMetricNumber(aggregateRating.reviewCount || aggregateRating.ratingCount),
          rawText: compactText(JSON.stringify(item)).slice(0, 3000)
        });
      }
    }
    return products;
  }

  function flattenJsonLd(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value.flatMap(flattenJsonLd);
    const graph = value["@graph"];
    if (Array.isArray(graph)) return graph.flatMap(flattenJsonLd);
    return [value];
  }

  function isProductLike(item) {
    const type = item?.["@type"];
    return type === "Product" || (Array.isArray(type) && type.includes("Product"));
  }

  function parseJson(value) {
    try {
      return JSON.parse(value || "");
    } catch {
      return null;
    }
  }

  function mergeProductData(product, structuredProducts) {
    const structured = structuredProducts.find((item) => item.url === product.url || item.ozonProductId === product.ozonProductId);
    if (!structured) return product;
    return {
      ...structured,
      ...product,
      title: product.title || structured.title,
      brand: product.brand || structured.brand,
      imageUrl: product.imageUrl || structured.imageUrl,
      priceRub: product.priceRub || structured.priceRub,
      rating: product.rating || structured.rating,
      reviewCount: product.reviewCount || structured.reviewCount,
      rawText: product.rawText || structured.rawText
    };
  }

  function extractPriceRub(text) {
    const pricePatterns = [
      /(?:цена|price|价格)[:：]?\s*([0-9][0-9\s.,]{1,12})\s*(?:₽|руб\.?|rub)/i,
      /([0-9][0-9\s.,]{1,12})\s*(?:₽|руб\.?|rub)/i
    ];

    for (const pattern of pricePatterns) {
      const match = text.match(pattern);
      if (!match) continue;
      const value = parseMoney(match[1]);
      if (Number.isFinite(value) && value > 0) return value;
    }
    return undefined;
  }

  function extractWeightGrams(text) {
    const match = text.match(/(?:重量|вес|weight)[:：]?\s*([0-9]+(?:[.,][0-9]+)?)\s*(kg|кг|g|гр|г|千克|公斤|克)/i);
    if (!match) return undefined;
    const value = Number(match[1].replace(",", "."));
    const unit = match[2].toLowerCase();
    if (!Number.isFinite(value)) return undefined;
    if (["kg", "кг", "千克", "公斤"].includes(unit)) return Math.round(value * 1000);
    return Math.round(value);
  }

  function extractDimensions(text) {
    const labeled = text.match(/(?:尺寸|体积|габариты|размер|dimensions?)[:：]?\s*([0-9]+(?:[.,][0-9]+)?)\s*[x×*]\s*([0-9]+(?:[.,][0-9]+)?)\s*[x×*]\s*([0-9]+(?:[.,][0-9]+)?)\s*(cm|см|mm|мм|厘米|毫米)?/i);
    if (labeled) {
      let [lengthCm, widthCm, heightCm] = [labeled[1], labeled[2], labeled[3]].map((value) => Number(value.replace(",", ".")));
      const unit = (labeled[4] || "cm").toLowerCase();
      if (["mm", "мм", "毫米"].includes(unit)) {
        lengthCm /= 10;
        widthCm /= 10;
        heightCm /= 10;
      }
      return { lengthCm, widthCm, heightCm, volumeCm3: lengthCm * widthCm * heightCm };
    }

    const volume = text.match(/(?:体积|volume)[:：]?\s*([0-9]+(?:[.,][0-9]+)?)\s*(cm3|cm³|立方厘米)/i);
    if (volume) return { volumeCm3: Number(volume[1].replace(",", ".")) };
    return {};
  }

  function firstNumber(text, patterns) {
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        const value = parseMetricNumber(match[1]);
        if (Number.isFinite(value)) return value;
      }
    }
    return undefined;
  }

  function parseMoney(value) {
    const normalized = String(value || "")
      .replace(/\s+/g, "")
      .replace(",", ".")
      .replace(/[^\d.]/g, "");
    const number = Number(normalized);
    if (!Number.isFinite(number)) return undefined;
    return Math.round(number);
  }

  function parseMetricNumber(value) {
    const raw = String(value || "").trim().toLowerCase().replace(/\s+/g, "");
    const number = Number(raw.replace(",", ".").replace(/[^\d.]/g, ""));
    if (!Number.isFinite(number)) return undefined;
    if (/[kк]/.test(raw)) return Math.round(number * 1000);
    if (/千/.test(raw)) return Math.round(number * 1000);
    if (/万/.test(raw)) return Math.round(number * 10000);
    return Math.round(number);
  }

  function extractByLabels(text, labels) {
    for (const label of labels) {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const match = text.match(new RegExp(`${escaped}[:：]?\\s*([^\\n|,，;；]{1,60})`, "i"));
      if (match) return match[1].trim();
    }
    return "";
  }

  function normalizeOzonUrl(url) {
    try {
      const parsed = new URL(url, location.origin);
      parsed.search = "";
      parsed.hash = "";
      return parsed.href;
    } catch {
      return "";
    }
  }

  function extractOzonProductId(url) {
    const match = String(url || "").match(/\/product\/[^/]*-(\d+)\//) || String(url || "").match(/\/product\/(\d+)/);
    return match?.[1] || "";
  }

  function extractImageUrl(card) {
    const image = card.querySelector("img");
    return normalizeImageUrl(image?.currentSrc || image?.src || image?.getAttribute("data-src") || "");
  }

  function normalizeImageUrl(url) {
    if (!url) return "";
    try {
      return new URL(url, location.origin).href;
    } catch {
      return "";
    }
  }

  function compactText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function clickNextPage() {
    const candidates = [
      'a[aria-label*="Следующая"]',
      'button[aria-label*="Следующая"]',
      'a[aria-label*="Вперёд"]',
      'button[aria-label*="Вперёд"]',
      'a[aria-label*="Next"]',
      'button[aria-label*="Next"]'
    ];
    for (const selector of candidates) {
      const nodes = [...document.querySelectorAll(selector)];
      const node = nodes.find((candidate) => {
        const text = compactText(candidate.innerText || candidate.getAttribute("aria-label") || "");
        const href = candidate.getAttribute("href") || "";
        return text.includes("След") || text.includes("Впер") || text.includes("Next") || /[?&]page=\d+/.test(href);
      });
      if (node && !node.disabled) {
        node.click();
        return true;
      }
    }
    return false;
  }
})();
