chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "MIAOSHOU_PUSH_LINKS") {
    pushLinks(message.config, message.links)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "MIAOSHOU_START_COLLECTION") {
    startCollectionTask(message.config)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "MIAOSHOU_STOP_COLLECTION") {
    stopCollectionTask()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === "MIAOSHOU_ACTIVATE_LICENSE") {
    activateLicense(message.config)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "MIAOSHOU_COLLECTION_TICK") {
    runTaskStep().catch((error) => failStoredTask(error));
  }
});

const taskState = {
  running: false,
  status: "待开始",
  scanned: 0,
  accepted: [],
  rejected: 0,
  pushed: 0,
  reasons: {},
  logs: [],
  config: null,
  phase: "idle",
  page: 1,
  scrollCount: 0,
  tabId: null
};

async function startCollectionTask(config) {
  const stored = await chrome.storage.local.get("taskState");
  if (stored.taskState?.running) throw new Error("已有采集任务正在运行");
  resetTaskState();
  taskState.running = true;
  taskState.config = config;
  taskState.phase = "license";
  taskState.page = 1;
  taskState.scrollCount = 0;
  await publishTaskState("准备打开网页");

  try {
    const tab = await chrome.tabs.create({ url: normalizeStartUrl(config.startUrl) || buildOzonSearchUrl(config.keyword), active: true });
    taskState.tabId = tab.id;
    await publishTaskState(`已打开采集页：${tab.url || buildOzonSearchUrl(config.keyword)}`);
    scheduleTaskTick(1000);
    return { started: true };
  } catch (error) {
    taskState.running = false;
    await publishTaskState(`出错：${String(error?.message || error)}`);
    throw error;
  }
}

async function runTaskStep() {
  await loadStoredTaskState();
  if (!taskState.running) return;
  const config = taskState.config || {};

  if (taskState.phase === "license") {
    await publishTaskState("校验授权");
    await activateLicense(config);
    taskState.phase = "wait_ready";
    await publishTaskState("授权有效，等待页面加载");
    scheduleTaskTick(1500);
    return;
  }

  if (taskState.phase === "wait_ready") {
    const tab = await chrome.tabs.get(taskState.tabId);
    if (tab.status !== "complete") {
      await publishTaskState("页面加载中");
      scheduleTaskTick(1500);
      return;
    }
    await injectCollectorScripts(taskState.tabId);
    taskState.phase = "scroll";
    taskState.scrollCount = 0;
    await publishTaskState(`开始采集第 ${taskState.page || 1} 页`);
    scheduleTaskTick(800);
    return;
  }

  if (taskState.phase === "scroll") {
    await injectCollectorScripts(taskState.tabId);
    await sendTabMessage(taskState.tabId, { type: "MIAOSHOU_SCROLL_PAGE" });
    taskState.scrollCount = Number(taskState.scrollCount || 0) + 1;
    await publishTaskState(`第 ${taskState.page || 1} 页滚动加载 ${taskState.scrollCount}/5`);
    if (taskState.scrollCount >= 5) taskState.phase = "scan";
    scheduleTaskTick(1400);
    return;
  }

  if (taskState.phase === "scan") {
    await injectCollectorScripts(taskState.tabId);
    const response = await sendTabMessage(taskState.tabId, { type: "MIAOSHOU_SCAN_PAGE", config });
    if (!response?.ok) throw new Error(response?.error || "扫描失败");
    mergeTaskProducts(response.products || []);
    const pageAccepted = (response.products || []).filter((item) => item.accepted).length;
    const pageRejected = Math.max(0, (response.products || []).length - pageAccepted);
    await publishTaskState(`第 ${taskState.page || 1} 页：扫描 ${response.products.length} 个，成功采集 ${pageAccepted} 个，拒绝 ${pageRejected} 个，累计成功 ${taskState.accepted.length}/${config.targetCount}`);
    await publishTopReasons();

    if (taskState.accepted.length >= Number(config.targetCount || 200)) {
      taskState.phase = "push";
    } else if (Number(taskState.page || 1) >= Number(config.maxPages || 20)) {
      taskState.phase = "push";
      await publishTaskState("已达到最多翻页数，准备推送");
    } else {
      taskState.phase = "next";
    }
    scheduleTaskTick(1000);
    return;
  }

  if (taskState.phase === "next") {
    const nextPage = Number(taskState.page || 1) + 1;
    const moved = await goNextPage(taskState.tabId, nextPage);
    if (!moved) {
      taskState.phase = "push";
      await publishTaskState("没有找到下一页，准备推送");
    } else {
      taskState.page = nextPage;
      taskState.phase = "wait_ready";
      await publishTaskState(`已进入第 ${nextPage} 页`);
    }
    scheduleTaskTick(2500);
    return;
  }

  if (taskState.phase === "push") {
    const links = taskState.accepted.slice(0, Number(config.targetCount || 200)).map((item) => item.url);
    if (!links.length) {
      taskState.running = false;
      taskState.phase = "done";
      await publishTaskState("无可推送");
      return;
    }
    await publishTaskState(`推送中：${links.length} 条`);
    const pushed = await pushLinks(config, links);
    taskState.pushed = pushed.pushed;
    taskState.running = false;
    taskState.phase = "done";
    await publishTaskState(`完成，已推送 ${taskState.pushed} 条`);
  }
}

async function loadStoredTaskState() {
  const stored = await chrome.storage.local.get("taskState");
  if (!stored.taskState) return;
  Object.assign(taskState, stored.taskState);
  taskState.accepted = stored.taskState.accepted || [];
  taskState.reasons = stored.taskState.reasons || {};
  taskState.logs = stored.taskState.logs || [];
}

async function failStoredTask(error) {
  await loadStoredTaskState();
  taskState.running = false;
  taskState.phase = "error";
  await publishTaskState(`出错：${String(error?.message || error)}`);
}

async function stopCollectionTask() {
  await loadStoredTaskState();
  chrome.alarms.clear("MIAOSHOU_COLLECTION_TICK");
  taskState.running = false;
  taskState.phase = "stopped";
  await publishTaskState("已停止采集");
  return { stopped: true };
}

function scheduleTaskTick(delayMs) {
  chrome.alarms.create("MIAOSHOU_COLLECTION_TICK", { when: Date.now() + delayMs });
}

async function activateLicense(config) {
  if (!config?.licenseKey) throw new Error("请先填写授权码");
  const deviceId = await getDeviceId();
  const response = await fetch(config.licenseApiUrl || "https://miaoshou-ozon-collector.hzijie995577.chatgpt.site/api/license/activate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      licenseKey: config.licenseKey,
      deviceId,
      extensionVersion: chrome.runtime.getManifest().version
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) {
    throw new Error(data.error || `授权服务器错误 ${response.status}`);
  }
  await chrome.storage.local.set({
    licenseState: {
      ok: true,
      licenseKey: String(config.licenseKey || "").trim().toUpperCase(),
      deviceId,
      checkedAt: new Date().toISOString(),
      message: data.message || "授权有效"
    }
  });
  return data;
}

async function getDeviceId() {
  const stored = await chrome.storage.local.get("deviceId");
  if (stored.deviceId) return stored.deviceId;
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  const id = [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  await chrome.storage.local.set({ deviceId: id });
  return id;
}

function resetTaskState() {
  taskState.running = false;
  taskState.status = "待开始";
  taskState.scanned = 0;
  taskState.accepted = [];
  taskState.rejected = 0;
  taskState.pushed = 0;
  taskState.reasons = {};
  taskState.logs = [];
  taskState.config = null;
  taskState.phase = "idle";
  taskState.page = 1;
  taskState.scrollCount = 0;
  taskState.tabId = null;
}

async function publishTaskState(status) {
  taskState.status = status;
  taskState.logs.unshift(`${new Date().toLocaleTimeString()} ${status}`);
  taskState.logs = taskState.logs.slice(0, 80);
  await chrome.storage.local.set({ taskState: { ...taskState, acceptedCount: taskState.accepted.length } });
}

function mergeTaskProducts(products) {
  taskState.scanned += products.length;
  const accepted = new Map(taskState.accepted.map((item) => [item.url, item]));
  for (const product of products) {
    if (product.accepted) {
      accepted.set(product.url, product);
    } else {
      taskState.rejected += 1;
      for (const reason of product.reasons || ["unknown"]) {
        taskState.reasons[reason] = (taskState.reasons[reason] || 0) + 1;
      }
    }
  }
  taskState.accepted = [...accepted.values()];
}

async function publishTopReasons() {
  const top = Object.entries(taskState.reasons || {})
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([reason, count]) => `${reason}:${count}`)
    .join("，");
  if (top) {
    await publishTaskState(`主要拒绝原因：${top}`);
  }
}

async function injectCollectorScripts(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["src/filters.js", "src/content-script.js"]
  }).catch(() => undefined);
}

async function sendTabMessage(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch {
    await injectCollectorScripts(tabId);
    await delay(500);
    return chrome.tabs.sendMessage(tabId, message);
  }
}

async function waitForTabReady(tabId) {
  for (let index = 0; index < 60; index += 1) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === "complete") return;
    await delay(500);
  }
}

async function autoScrollAndWait(tabId) {
  for (let index = 0; index < 5; index += 1) {
    await sendTabMessage(tabId, { type: "MIAOSHOU_SCROLL_PAGE" });
    await delay(1400);
  }
}

async function goNextPage(tabId, nextPage) {
  const clicked = await sendTabMessage(tabId, { type: "MIAOSHOU_NEXT_PAGE" });
  if (clicked?.clicked) return true;

  const tab = await chrome.tabs.get(tabId);
  const nextUrl = buildNextPageUrl(tab.url, nextPage);
  if (!nextUrl || nextUrl === tab.url) return false;
  await chrome.tabs.update(tabId, { url: nextUrl });
  return true;
}

function normalizeStartUrl(value) {
  if (!value) return "";
  const parsed = new URL(value);
  if (!parsed.hostname.includes("ozon.ru")) throw new Error("起始链接必须是 Ozon 页面");
  return parsed.href;
}

function buildOzonSearchUrl(keyword) {
  const query = encodeURIComponent(keyword || "干发帽");
  return `https://www.ozon.ru/search/?text=${query}`;
}

function buildNextPageUrl(url, nextPage) {
  try {
    const parsed = new URL(url);
    if (!parsed.hostname.includes("ozon.ru")) return "";
    parsed.searchParams.set("page", String(nextPage));
    return parsed.href;
  } catch {
    return "";
  }
}

async function pushLinks(config, links) {
  if (!config?.appKey || !config?.appSecret) {
    throw new Error("Missing Miaoshou appKey/appSecret");
  }

  const cleanLinks = [...new Set((links || []).filter(Boolean))];
  const batchSize = Math.min(Number(config.batchSize || 50), 50);
  const batches = chunk(cleanLinks, batchSize);
  const results = [];

  for (const batch of batches) {
    const body = { collectLinks: batch };
    const result = await postMiaoshou(config, "/open/v1/product/common_collect_box/common_collect_box/fetch_item", body);
    results.push({ count: batch.length, result });
  }

  return { pushed: cleanLinks.length, batches: results };
}

async function postMiaoshou(config, path, body) {
  const baseUrl = (config.apiBaseUrl || "https://openapi-erp.91miaoshou.com").replace(/\/+$/, "");
  const timestamp = String(Math.floor(Date.now() / 1000));
  const bodyJson = JSON.stringify(body);
  const sign = await signMiaoshou(config.appSecret, path, timestamp, config.appKey, bodyJson);

  const response = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-app-key": config.appKey,
      "x-timestamp": timestamp,
      "x-sign": sign
    },
    body: bodyJson
  });

  const text = await response.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new Error(`Miaoshou returned non-JSON response: ${text.slice(0, 500)}`);
  }

  if (!response.ok) {
    throw new Error(`Miaoshou HTTP ${response.status}: ${text.slice(0, 500)}`);
  }

  if (data.success === false || (data.code && data.code !== "success") || (data.result && data.result !== "success")) {
    throw new Error(`Miaoshou API error: ${JSON.stringify(data).slice(0, 800)}`);
  }

  return data;
}

async function signMiaoshou(appSecret, path, timestamp, appKey, bodyJson) {
  const content = `${appSecret}${path}${timestamp}${appKey}${bodyJson || ""}${appSecret}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(appSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(content));
  return [...new Uint8Array(signature)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function chunk(items, size) {
  const result = [];
  for (let index = 0; index < items.length; index += size) {
    result.push(items.slice(index, index + size));
  }
  return result;
}
