import { DEFAULT_CONFIG } from "./defaults.js";

const fields = {
  appKey: textField("appKey"),
  appSecret: textField("appSecret"),
  licenseKey: textField("licenseKey"),
  licenseApiUrl: textField("licenseApiUrl"),
  updateCheckUrl: textField("updateCheckUrl"),
  keyword: textField("keyword"),
  startUrl: textField("startUrl"),
  targetCount: numberField("targetCount"),
  maxPages: numberField("maxPages"),
  minPrice: numberField("minPrice"),
  maxPrice: numberField("maxPrice"),
  minSales: numberField("minSales"),
  maxListingDays: numberField("maxListingDays"),
  maxSellerCount: numberField("maxSellerCount"),
  requireWeight: checkboxField("requireWeight"),
  requireVolume: checkboxField("requireVolume"),
  forbiddenKeywords: listField("forbiddenKeywords"),
  blockedBrands: listField("blockedBrands")
};

const state = {
  scanned: 0,
  accepted: new Map(),
  rejected: 0,
  pushed: 0,
  reasons: new Map()
};

document.getElementById("save").addEventListener("click", withError(saveConfig));
document.getElementById("activate").addEventListener("click", withError(activateLicense));
document.getElementById("scan").addEventListener("click", withError(scanCurrentPage));
document.getElementById("diagnose").addEventListener("click", withError(diagnoseCurrentPage));
document.getElementById("start").addEventListener("click", withError(startCollection));
document.getElementById("stop").addEventListener("click", withError(stopCollection));
document.getElementById("reload").addEventListener("click", reloadExtension);
document.getElementById("checkUpdate").addEventListener("click", withError(checkUpdate));

loadConfig();
loadTaskState();
renderLocalVersion();
setTimeout(() => checkUpdate({ silent: true }).catch(() => undefined), 800);
setInterval(loadTaskState, 1500);

async function loadConfig() {
  const stored = await chrome.storage.local.get("config");
  const config = { ...DEFAULT_CONFIG, ...(stored.config || {}) };
  for (const [key, field] of Object.entries(fields)) field.set(config[key]);
}

async function saveConfig() {
  const config = readConfig();
  await chrome.storage.local.set({ config });
  setStatus("已保存");
  log("设置已保存");
}

async function activateLicense() {
  await saveConfig();
  setStatus("授权校验中");
  const config = readConfig();
  const response = await chrome.runtime.sendMessage({ type: "MIAOSHOU_ACTIVATE_LICENSE", config });
  if (!response?.ok) throw new Error(response?.error || "授权失败");
  setStatus("授权有效");
  log(response.result?.message || "授权已激活");
}

async function scanCurrentPage() {
  const config = readConfig();
  const tab = await getActiveTab();
  const response = await chrome.tabs.sendMessage(tab.id, { type: "MIAOSHOU_SCAN_PAGE", config });
  if (!response?.ok) throw new Error(response?.error || "扫描失败");
  mergeProducts(response.products || []);
  renderStats();
  log(`本页扫描 ${response.products.length} 个，通过 ${response.products.filter((item) => item.accepted).length} 个`);
  logReasonSamples(response.products || []);
}

async function diagnoseCurrentPage() {
  const config = { ...readConfig(), minSales: 0, maxListingDays: 0, maxSellerCount: 0, requireWeight: false, requireVolume: false };
  const tab = await getActiveTab();
  const response = await chrome.tabs.sendMessage(tab.id, { type: "MIAOSHOU_SCAN_PAGE", config });
  if (!response?.ok) throw new Error(response?.error || "诊断失败");
  const products = response.products || [];
  log(`诊断：本页识别到 ${products.length} 个商品`);
  for (const product of products.slice(0, 5)) {
    log(formatProductDebug(product));
  }
}

async function startCollection() {
  await saveConfig();
  const config = readConfig();
  setStatus("后台启动中");
  log("后台任务已启动，打开网页后弹窗关闭也会继续运行");
  const response = await chrome.runtime.sendMessage({ type: "MIAOSHOU_START_COLLECTION", config });
  if (!response?.ok) throw new Error(response?.error || "后台任务启动失败");
  await loadTaskState();
}

async function stopCollection() {
  setStatus("正在停止");
  const response = await chrome.runtime.sendMessage({ type: "MIAOSHOU_STOP_COLLECTION" });
  if (!response?.ok) throw new Error(response?.error || "停止失败");
  await loadTaskState();
}

async function checkUpdate(options = {}) {
  const config = readConfig();
  const box = document.getElementById("updateBox");
  const title = document.getElementById("updateTitle");
  const message = document.getElementById("updateMessage");
  const download = document.getElementById("downloadUpdate");
  const currentVersion = chrome.runtime.getManifest().version;

  if (!config.updateCheckUrl) {
    if (options.silent) return;
    throw new Error("请先填写更新检查地址");
  }

  if (!options.silent) {
    box.hidden = false;
    title.textContent = "正在检查更新";
    message.textContent = "正在读取最新版本信息...";
    download.hidden = true;
  }

  let latest;
  try {
    const response = await fetchWithTimeout(config.updateCheckUrl, { cache: "no-store" }, 8000);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    latest = await response.json();
    if (!latest?.version) throw new Error("version.json 缺少 version");
  } catch (error) {
    box.hidden = false;
    title.textContent = "更新检查失败";
    message.textContent = `无法读取更新信息：${String(error?.message || error)}。请确认 GitHub 根目录已上传 version.json，或先忽略更新检查继续使用插件。`;
    download.hidden = true;
    if (options.silent) return;
    log(`更新检查失败：${String(error?.message || error)}`);
    return;
  }

  const hasUpdate = compareVersions(latest.version, currentVersion) > 0;
  box.hidden = false;
  title.textContent = hasUpdate ? "发现新版本" : "已是最新版本";
  message.textContent = hasUpdate
    ? `当前版本 ${currentVersion}，最新版本 ${latest.version}。${latest.notes || ""}`
    : `当前版本 ${currentVersion}，最新版本 ${latest.version}。`;

  download.hidden = !hasUpdate || !latest.downloadUrl;
  download.onclick = () => chrome.tabs.create({ url: latest.downloadUrl });
}

async function fetchWithTimeout(url, init, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("请求超时");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function mergeProducts(products) {
  state.scanned += products.length;
  for (const product of products) {
    if (product.accepted) {
      state.accepted.set(product.url, product);
    } else {
      state.rejected += 1;
      for (const reason of product.reasons || ["unknown"]) {
        state.reasons.set(reason, (state.reasons.get(reason) || 0) + 1);
      }
    }
  }
}

function readConfig() {
  const config = { ...DEFAULT_CONFIG };
  for (const [key, field] of Object.entries(fields)) config[key] = field.get();
  config.batchSize = Math.min(Number(config.batchSize || 50), 50);
  return config;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("没有可用标签页");
  if (!tab.url?.includes("ozon.ru")) throw new Error("请先打开 Ozon 页面");
  return tab;
}

function renderStats() {
  document.getElementById("scanned").textContent = String(state.scanned);
  document.getElementById("accepted").textContent = String(state.accepted.size);
  document.getElementById("rejected").textContent = String(state.rejected);
  document.getElementById("pushed").textContent = String(state.pushed);
  renderReasons();
}

async function loadTaskState() {
  const stored = await chrome.storage.local.get("taskState");
  if (!stored.taskState) return;
  const task = stored.taskState;
  document.getElementById("scanned").textContent = String(task.scanned || 0);
  document.getElementById("accepted").textContent = String(task.acceptedCount || 0);
  document.getElementById("rejected").textContent = String(task.rejected || 0);
  document.getElementById("pushed").textContent = String(task.pushed || 0);
  setStatus(task.status || "待开始");

  const box = document.getElementById("reasonBox");
  const list = document.getElementById("reasonList");
  const reasons = Object.entries(task.reasons || {}).sort((a, b) => b[1] - a[1]).slice(0, 6);
  box.hidden = reasons.length === 0;
  list.textContent = "";
  for (const [reason, count] of reasons) {
    const item = document.createElement("li");
    item.textContent = `${translateReason(reason)}：${count}`;
    list.append(item);
  }

  if (Array.isArray(task.logs)) {
    document.getElementById("log").textContent = task.logs.join("\n").slice(0, 5000);
  }

  document.getElementById("stop").disabled = !task.running;
}

function renderReasons() {
  const box = document.getElementById("reasonBox");
  const list = document.getElementById("reasonList");
  const reasons = [...state.reasons.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);
  box.hidden = reasons.length === 0;
  list.textContent = "";
  for (const [reason, count] of reasons) {
    const item = document.createElement("li");
    item.textContent = `${translateReason(reason)}：${count}`;
    list.append(item);
  }
}

function logReasonSamples(products) {
  const rejected = products.filter((item) => !item.accepted).slice(0, 3);
  for (const product of rejected) {
    log(`拒绝样例：${(product.title || product.url || "未知商品").slice(0, 36)} ｜ ${formatReasons(product.reasons)}`);
  }
}

function formatReasons(reasons) {
  return (reasons || ["unknown"]).map(translateReason).join("，");
}

function formatProductDebug(product) {
  const fields = [
    `标题=${short(product.title) || "-"}`,
    `价格=${product.priceRub || "-"}`,
    `品牌=${product.brand || "-"}`,
    `评分=${product.rating || "-"}`,
    `评论=${product.reviewCount || "-"}`,
    `销量=${product.sales || "-"}`,
    `上架天数=${product.listingDays || "-"}`,
    `跟卖=${product.sellerCount ?? "-"}`,
    `重量g=${product.weightGrams || "-"}`,
    `体积=${product.volumeCm3 ? Math.round(product.volumeCm3) : "-"}`,
    `链接=${product.url || "-"}`
  ];
  return `识别样例：${fields.join(" ｜ ")}`;
}

function short(value) {
  return String(value || "").slice(0, 38);
}

function translateReason(reason) {
  if (reason === "missing_url") return "缺商品链接";
  if (reason === "missing_title") return "缺标题";
  if (reason.startsWith("sales<")) return "销量不足或未识别";
  if (reason.startsWith("listing_days>")) return "上架天数超限或未识别";
  if (reason.startsWith("seller_count>")) return "跟卖数超限或未识别";
  if (reason.startsWith("price<")) return "价格低于最低价或未识别";
  if (reason.startsWith("price>")) return "价格高于最高价或未识别";
  if (reason === "missing_weight") return "缺重量";
  if (reason === "missing_volume") return "缺体积";
  if (reason.startsWith("forbidden_keyword:")) return `违禁词：${reason.split(":").slice(1).join(":")}`;
  if (reason.startsWith("blocked_brand:")) return `屏蔽品牌：${reason.split(":").slice(1).join(":")}`;
  return reason || "未知原因";
}

function setStatus(value) {
  document.getElementById("status").textContent = value;
}

function renderLocalVersion() {
  const label = document.getElementById("versionLabel");
  label.textContent = `v${chrome.runtime.getManifest().version} ZIP升级版`;
}

function compareVersions(a, b) {
  const left = String(a).split(".").map((part) => Number(part) || 0);
  const right = String(b).split(".").map((part) => Number(part) || 0);
  const length = Math.max(left.length, right.length);
  for (let index = 0; index < length; index += 1) {
    const diff = (left[index] || 0) - (right[index] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function log(value) {
  const node = document.getElementById("log");
  node.textContent = `${new Date().toLocaleTimeString()} ${value}\n${node.textContent}`.slice(0, 5000);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function textField(id) {
  const node = document.getElementById(id);
  return { get: () => node.value.trim(), set: (value) => (node.value = value || "") };
}

function numberField(id) {
  const node = document.getElementById(id);
  return { get: () => Number(node.value), set: (value) => (node.value = Number(value || 0)) };
}

function checkboxField(id) {
  const node = document.getElementById(id);
  return { get: () => node.checked, set: (value) => (node.checked = Boolean(value)) };
}

function listField(id) {
  const node = document.getElementById(id);
  return {
    get: () => node.value.split("\n").map((item) => item.trim()).filter(Boolean),
    set: (value) => (node.value = (value || []).join("\n"))
  };
}

function withError(handler) {
  return async () => {
    try {
      await handler();
    } catch (error) {
      setStatus("出错");
      log(`错误：${String(error?.message || error)}`);
    }
  };
}

function reloadExtension() {
  chrome.runtime.reload();
}
